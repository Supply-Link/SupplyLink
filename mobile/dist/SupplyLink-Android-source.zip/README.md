# SupplyLink

A professional pharmaceutical distribution portal for administrators, distributors, retailers, and delivery partners. One Python process hosts the web portal and a small local LDAP directory. Records persist in one transactional JSON file. No third-party Python packages, Node.js, database server, or Docker required.

## Start

Python 3.9+ on macOS or Linux:

```sh
cd /Users/rajeevchakraborty/Downloads/src/supplylink
python3 server.py
```

- Portal: **http://127.0.0.1:8000**
- Registration: **http://127.0.0.1:8000/register**
- Local LDAP: **ldap://127.0.0.1:1389**
- Base DN: **dc=supplylink,dc=local**
- Storage: `data/portal.json`

Both listeners bind to localhost by default; LDAP is always loopback-only. Use `--port 8080 --ldap-port 1390 --data /path/to/portal.json` for alternative settings, or `--no-ldap` for the portal alone. If a requested port is unavailable, startup fails with an error instead of silently omitting the directory.

## Demo sign-in

Use the demo buttons or these accounts. All initial passwords are **Demo@123**.

| Role | Email | LDAP bind DN |
| --- | --- | --- |
| Administrator | admin@supplylink.local | uid=admin,ou=people,dc=supplylink,dc=local |
| Distributor | distributor@supplylink.local | uid=distributor,ou=people,dc=supplylink,dc=local |
| Retailer | retailer@supplylink.local | uid=retailer,ou=people,dc=supplylink,dc=local |
| Second retailer | retailer2@supplylink.local | uid=retailer2,ou=people,dc=supplylink,dc=local |
| Delivery partner | delivery@supplylink.local | uid=delivery,ou=people,dc=supplylink,dc=local |

Use separate browser profiles/private windows for simultaneous roles. Tabs in one browser profile share the session cookie. Reload to see updates from other users. The initial catalog contains 24 generic medicine entries. All seeded prices, manufacturers, batches, dates, MRP, stock, and tax configuration are sample data.

## Registration and administrator approval

1. A user opens `/register` and submits their name, business, email, password, address, state, and requested retailer/distributor/delivery role. GSTIN and drug licence number are optional.
2. Registration creates a **pending, inactive** account. Supplied active flags, credit limits, and administrator-role requests cannot grant access.
3. An administrator opens **People & roles → Pending requests → Review access**, selects the approved role, and approves or rejects the request. Rejections record a reason and may be reviewed again.
4. Approval enables web and LDAP sign-in with the registered password. Retailer credit initially starts at zero; administrators configure it separately.
5. Deactivation disables both entry points and permanently revokes existing web sessions. Existing LDAP connections recheck account status before subsequent searches.

Administrators may also create approved accounts directly. Business/GST and drug-licence identifiers are format-checked and stored; government registry verification and email verification are not connected. There is no password reset or account recovery workflow yet.

## Medicine and batch inventory

**Medicine master:** display name, generic name, strength, dosage form, manufacturer, brand/catalog label, trade pack, SKU, category, storage conditions, HSN, configurable GST rate, selling price excluding GST, reorder threshold, and availability.

**Each batch:** batch ID/lot number, manufacturing date, expiry date, available quantity in trade packs, MRP per pack including GST, purchase price excluding GST, and quarantine status.

- Administrators/distributors create medicines, then use **Batches → Receive batch** to record stock and batch facts.
- Stock adjustments require a batch and reason. They cannot make unreserved stock negative. Quarantine/release actions also require a reason.
- Orders reserve available batches in **first-expiry-first-out** order and may split quantities across batches.
- Expired and quarantined stock is excluded from ordering. Confirmation, packing, and dispatch reject expired or quarantined reserved batches.
- Expiry is valid through the entered calendar date, using India time. If a label lists only month/year, enter its final day. The portal highlights available batches expiring within 90 days.
- Selling price including configured GST must not exceed the selected batch MRP.
- Cancellation restores the same batch quantities and releases trade credit once. Retailers can cancel placed/confirmed unpaid orders; administrators/distributors may also cancel packed unpaid orders before dispatch.
- Purchase costs are hidden from retailer responses. Delivery partners receive only assigned orders and no catalog inventory.

## GST and order records

Configure **Business & GST** for the supplier/buyer legal name, address, GSTIN, registered state, and drug licence. Administrators can maintain multiple business profiles; other business roles can edit only their own.

New checkout uses a server-calculated quote. Selling prices exclude GST; the final total includes GST. Discounts apply before tax. The explicitly selected delivery state/place of supply determines the sample intra-state CGST+SGST (or CGST+UTGST for applicable Union Territories) or interstate IGST split. Each component rounds half-up to paise; independently rounded local components can differ by one paisa from a combined IGST calculation.

Order records retain original batch allocations, manufacturing/expiry dates, MRP, HSN, rates, taxable amounts, tax components, and business profiles. Later product/profile changes do not rewrite them. A stale displayed total is rejected at order placement. Order details provide a tax summary, **not a statutory GST invoice**. Invoice issuance, GST returns, e-invoicing, special place-of-supply cases, and tax classification verification are not implemented.

The seed uses a configurable **sample 5% GST rate and HSN heading 3004**, not a verified item-specific classification. Confirm real rates/classifications before using commercial data. Reference: [Government of India medicine GST reforms](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2163785&lang=2&reg=48) and [CBIC tax-invoice particulars](https://cbic-gst.gov.in/gst-invoice-rules.html).

## Fulfilment, payments, and tracking

Retailer places an order → distributor confirms → packs → assigns a delivery partner and dispatches → assigned partner completes delivery. The order timeline has a distinct icon for every stage and cancellation. Notifications are in-portal.

Orders support cash on delivery or internal trade credit. Credit is reserved at placement and released upon cancellation or recorded payment. Payments are **manual records of money received outside the portal**. Record the full delivered order amount and a receipt reference once; duplicate order/payment requests are protected by idempotency keys. There are no real money transfers, partial payments, refunds, or returns. GPS is explicitly shared once by the driver or entered manually; continuous tracking is not implemented.

## Local LDAP directory

This is a small read-only **LDAPv3 protocol service**, not OpenLDAP or Active Directory. Portal login and LDAP simple bind use the same file-directory authentication function, password hashes, approval status, and active flag. The portal does not depend on a loopback LDAP network call for its own login.

Supported operations: LDAPv3 simple bind, anonymous root-DSE discovery, base/one-level/subtree search, equality/presence/substring/AND/OR/NOT filters, unbind, and Who Am I. Anonymous user enumeration is denied. Administrators can search all directory users; other users see only their own record and role membership. Group entries are under `ou=groups`. Password hashes, session tokens, tax identifiers, and addresses are never exposed as LDAP attributes.

Unsupported: LDAP writes (modify/add/delete/rename), SASL, paging, StartTLS, full schema services, replication, and external LDAP synchronization. Critical unsupported controls are rejected. Manage users in the portal. Plain LDAP is loopback-only development mode; optional LDAPS can be enabled with your certificate and key:

```sh
python3 server.py --ldap-cert /path/to/server.crt --ldap-key /path/to/server.key
```

This uses TLS 1.2+ and the configured LDAP port. Use `ldaps://127.0.0.1:1389` with a certificate trusted by the client and valid for that hostname/IP. The application does not generate or install trust certificates.

Example using installed OpenLDAP client tools (password prompt):

```sh
ldapwhoami -x -H ldap://127.0.0.1:1389 -D 'uid=admin,ou=people,dc=supplylink,dc=local' -W
ldapsearch -x -H ldap://127.0.0.1:1389 -D 'uid=admin,ou=people,dc=supplylink,dc=local' -W -b 'ou=people,dc=supplylink,dc=local' '(objectClass=inetOrgPerson)' uid cn mail title
```

## Persistence and migration

Passwords use salted PBKDF2-SHA256; sessions store token hashes. The portal uses HttpOnly/SameSite session cookies, CSRF tokens, origin checks, server-side roles/ownership, input validation, and basic sign-in/registration/bind throttling.

Every transaction locks the companion file, reads current records, and commits only on success through a temporary file, fsync, and atomic replacement. All money is integer paise. Cooperating processes on one host serialize writes. The main data file and migration backups are owner-readable/writable. JSON storage is for a small local deployment, not multiple hosts or large datasets.

Schema upgrades automatically save a confidential backup in `data/backups` before migration. Existing order totals/history remain unchanged. Legacy orders explicitly show that batch/tax facts were not captured; they are not assigned invented historical metadata. Seeded demo medicine stock receives sample batches. Non-demo stock without batch facts is retained as unallocated stock and excluded from ordering; confirm its label details through **Receive batch → Allocate historical stock**. Cancelling a legacy untracked medicine order similarly restores unallocated stock for review.

Stop the server before manually backing up, restoring, or editing the data file. Corrupt JSON is never silently reseeded. To reset the demo, move the file to a backup location while stopped, then restart.

## Testing

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

Tests use temporary files and isolated HTTP/LDAP ports; they do not modify live portal records. They cover end-to-end fulfilment/payment, file persistence and migration, role/record isolation, approval/rejection, deactivation/session revocation, LDAP clients and failed rebinds, anonymous denial, batch FEFO allocation and cancellation, expired/quarantined stock, invalid dates/MRP, tax breakdowns and immutable snapshots, stale quotes, idempotency, concurrent stock reservation, CSRF, and origin validation. Native LDAP-client checks require `ldapsearch` and `ldapwhoami`; they skip when unavailable.

## Operational limits

This is a local demonstration with demo credentials and Python's development HTTP server. A shared deployment needs proper HTTPS/app hosting, `COOKIE_SECURE=1`, replacement credentials, recovery workflows, reliable backups, and monitoring. Real pharmaceutical operation also needs validated supplier/licence/tax data, prescription/dispensing requirements, recalls/returns, and cold-chain workflows where relevant. These integrations are not implied by the sample catalog.

Generic medicine references: [CDSCO National List of Essential Medicines 2022](https://cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadConsumer/nlem2022.pdf). Batch-label reference: [CDSCO Drugs Rules](https://www.cdsco.gov.in/opencms/opencms/en/Acts-and-rules/Drugs-Rules/).

## Software expiry and distributor secret store

The software licence is separate from business data and user roles. The portal reads an offline, RSA-SHA256 signed licence from `.secrets/software-license.json` and verifies it with `config/license-public.pem`. The secret-store directory uses owner-only permissions (0700), and the signed licence file uses 0600. Expiry metadata is signed rather than encrypted. The signing private key is kept **outside the application folder**, at the issuer/distributor, and must never be included in a customer distribution or Git repository.

For this workspace, the issuer key was created at:

```text
/Users/rajeevchakraborty/Downloads/src/supplylink-issuer/license-signing-private.pem
```

Back that key up securely. Losing it prevents issuance of licences accepted by the existing verification key. Normal portal administrators cannot change software expiry through any portal API or business-data field.

### Set the expiry date before distribution or renew it later

From the application directory, substitute the agreed expiry date:

```sh
python3 license_admin.py issue \
  --private-key /Users/rajeevchakraborty/Downloads/src/supplylink-issuer/license-signing-private.pem \
  --expires YYYY-MM-DD \
  --customer 'Customer name'
python3 license_admin.py status
```

The expiry date remains **unconfigured until the distributor sets it**; no commercial expiry or trial duration is assumed. A licence is valid through the final instant of its expiry date in Asia/Kolkata, and becomes expired at 00:00 on the following day. For example, a licence ending 2026-12-31 blocks business actions from 2027-01-01 00:00 India time.

If setting up a new issuer for a separate product distribution, create keys once, with the issuer directory outside that application:

```sh
python3 license_admin.py init-issuer --issuer-dir /secure/distributor-issuer
```

This refuses to replace existing issuer/verification keys. The `issue` command can write a customer licence to another location with `--output /path/to/customer/.secrets/software-license.json`. Ship the app, its verification key, and the customer's signed licence; do not ship the issuer directory. `.secrets/` and the locally provisioned verification key are excluded from Git, so include them explicitly in a distribution package. OpenSSL or LibreSSL must be available on the server for signature verification and on the issuer machine for signing. No additional Python packages are needed.

### Expired or unavailable licence behavior

- Approved, active users can still sign in and sign out. Wrong passwords, pending registrations, and deactivated accounts remain rejected.
- All business reads and writes are blocked for every role, including administrators: catalog/state access, orders, batch stock, payments, credit, business profiles, account approval/creation, registration, notifications, and tracking. There is no read-only business dashboard after expiry.
- Existing sessions do not bypass the restriction. Server checks run on every business request and again before committing writes, so expiry during a write rolls back the transaction.
- Login/session metadata, licence status, static sign-in assets, and health checks remain available to support sign-in. Expired authentication responses contain only ID, name, and role, not business/credit data.
- LDAP simple bind and authentication identity remain available; LDAP searches are blocked, including on previously bound connections.
- The UI clears its in-memory business state and order basket and presents a sign-in-only screen. It checks expiry using server time, checks on focus/visibility changes, and detects licence replacement within 15 seconds. The backend enforces the cutoff independently of the UI.
- Missing, malformed, modified, wrongly signed, or publicly readable licence files fail closed into login-only mode. No expiry date is read from the ordinary JSON database.
- Replacing the licence with a valid signed renewal restores access without restarting the application. Existing business records are retained. Already downloaded files cannot be recalled.

Runtime paths may be selected with `--license-file` and `--license-public-key`. These are distributor/server configuration options, not portal permissions.

This is offline enforcement on a trusted host: an owner who can alter application source, replace its trust key, or manipulate the system clock can bypass local software controls. It is not hardware-backed licensing, a cloud secret vault, or protection against a hostile machine administrator.

### Licence verification coverage

The full test suite also covers signature tampering, wrong keys, unsafe permissions, absent/corrupt files, exact India-midnight boundaries, every role's expired login/logout, all business endpoints blocked without data changes, pre-expiry sessions, expiry during a transaction, LDAP bind/search separation, and live renewal without restart. Test-only licences use isolated keys/files and do not set your installation's commercial expiry.

The optional JavaScriptCore check in `tests/test_license_ui.py` verifies the licence UI templates and in-memory cache clearing with DOM stubs; it is not a visual browser-layout test. It skips where JavaScriptCore is unavailable.

## Native Android apps

The `android/` Gradle project builds two native Java apps for Android 8.0 and later:

- **SupplyLink Retailer** (`com.supplylink.retailer`): approved-account login and registration, medicine search, batch/manufacturing/expiry/MRP and GST details, basket quantities, server GST quotes, COD/trade-credit checkout, orders and cancellation, stage icons, notifications, business tax profile and payment history.
- **SupplyLink Delivery** (`com.supplylink.delivery`): approved-account login and registration, assigned deliveries, order/batch/tax details and timeline, one-time foreground location sharing with explicit confirmation, delivery confirmation, offline collection recording with receipt reference, notifications and payment history. There is no continuous/background GPS tracking.

Both use the same Python backend and JSON file as the web portal. Administrators and distributors use the existing web portal; those roles cannot open either mobile workspace. Registrations require administrator approval. These apps require a network connection. No medicine data, basket, password or session is persisted on the phone; only the chosen server URL is saved. Rotating or restarting the app requires signing in again. Business writes are not automatically retried; order and collection requests use idempotency keys for retries within the session.

### Install and connect

Installable **debug/test APKs** are in `android/dist/`. These are for local installation and evaluation, not Play Store publication. The main installation remains **unconfigured** for software licensing, so approved accounts can sign in but cannot open business features until a licence is provisioned at distribution.

For an Android emulator, start the backend normally (`python3 server.py`), then use server URL `http://10.0.2.2:8000` in either app. For a USB-connected Android phone with USB debugging enabled:

```sh
adb install -r android/dist/SupplyLink-Retailer-debug.apk
adb install -r android/dist/SupplyLink-Delivery-debug.apk
adb reverse tcp:8000 tcp:8000
```

Use `http://127.0.0.1:8000` as the server URL on that phone. The debug build permits plain HTTP only for the emulator host, localhost and 127.0.0.1. A remotely hosted deployment needs a trusted HTTPS endpoint in front of the backend; enter its origin (for example `https://supplylink.example.com`), without `/api` or another path. Android trusts system certificate authorities. Release builds enforce HTTPS for every server URL. The apps contain no licence issuer key, commercial licence or backend data file.

Demo logins are `retailer@supplylink.local` and `delivery@supplylink.local`, password `Demo@123`, once the installation is appropriately licensed. Use separate, approved accounts for real users. The apps use backend authentication, including its existing directory integration; they do not connect directly to an LDAP port.

### Build from source

Install JDK 17, Android SDK platform 35 and build-tools 34.0.0 (the Gradle plugin default). Put your SDK location in `android/local.properties` as `sdk.dir=/absolute/path/to/android-sdk`, or set `ANDROID_HOME`. Then:

```sh
cd android
./gradlew :app:assembleDebug :app:testRetailerDebugUnitTest :app:testDeliveryDebugUnitTest :app:lintRetailerDebug :app:lintDeliveryDebug
```

Output APKs are under `app/build/outputs/apk/retailer/debug/` and `delivery/debug/`. Run `python3 tools/package.py` from the `android/` directory to refresh the `dist/` APKs, source ZIP, installation notes and checksums. The Gradle wrapper pins Gradle 8.9 and its SHA-256 checksum. Both flavours share the native UI/API code, with a separate delivery-only GPS implementation and permission manifest. The retailer APK has no location permission. There are no third-party runtime UI or networking dependencies.

For distribution, build `:app:assembleRelease` and sign each resulting unsigned APK with your Android app signing key using Android Studio or Android build tools. Keep that key private and back it up; use the same key for future updates. Android APK signing is separate from the server's software-licence signing key. The supplied debug APKs use an ordinary development certificate. They should be replaced with your release-signed builds for customer distribution. Do not package the server issuer directory in either APK.

### Android verification

Unit tests cover server URL validation/HTTPS enforcement, monetary formatting, cancellation stages and coordinate bounds. Device instrumentation tests exercise actual Android networking (session cookies, CSRF and role access), registration/approval, GST quote → batch-allocated order → assigned delivery → tracking → delivery → idempotent collection, unconfigured/expired licences, and native login/navigation/checkout/expiry-lock screens.

To repeat device tests, boot an Android emulator, run `python3 android/tools/qa_server.py` in another terminal, then run:

```sh
cd android
./gradlew :app:connectedRetailerDebugAndroidTest :app:connectedDeliveryDebugAndroidTest
```

The QA helper binds only localhost ports 18001–18004. It creates disposable server data and separate test issuer keys/licences inside a temporary directory and removes them on exit. It never activates the main installation. Android tests connect through the emulator's `10.0.2.2` host alias. Device results and HTML reports are generated under `android/app/build/reports/`. Actual GPS reception, manufacturer-specific behavior and release deployment require validation on the intended physical phones.
